#! /bin/bash
#punto 5 - Ayuda
if [[ "$1" = "-help" ]]; then
	echo "Este script se debe ejecutar con dos parametros, el primero <origen> se debe indicar el directorio que se quiere backupear, el segundo <destino> es el directorio donde se alojara el archivo de backup"

	exit 0
fi

#punto 4 - Aceptar argumentos 
ORIGEN=$1 #Lo que se va backupear
DESTINO=${2:-/backup_dir} #Donde se va a backupear

#punto 6 - validar que estan montados
if [[ ! -d "$ORIGEN" ]]; then
	echo "El directorio ingresado como Origen para ser backupeado no existe, por favor verificar."
	exit 1
elif [[ ! -d "$DESTINO" ]]; then
	echo "El directorio ingresado como DESTINO para guardar el backup no existe, porfavor verificar."
	exit 2
fi

#nombre y fecha formato ANSI (YYMMDD)
FECHA=$(date +%Y%m%d) #toma la fecha del momento de ejecucion en formato ANSI
NOMBRE_ORIGEN=$(basename "$ORIGEN") #se pasa la variable ORIGEN por el comando "basename" para extraer solo el nombre del archivo o directorio, quitando la ruta principal, para poder utilizarlo en el nombre del archivo de BKP
ARCHIVO="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz" #definimos el nombre del archivo de BKP con su fecha y directorio/archivo origen correspondiente

#Almacenamiento de backup
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"
echo "Backup creado: $DESTINO/$ARCHIVO"
