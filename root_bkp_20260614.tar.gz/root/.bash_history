history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostnamectl set-hostname TPServer
hostname
nano /etc/hosts
cat /etc/hosts
shutdown
shutdown now
lsb_release -a
vi /etc/apt/sources.list
apt update
apt full-upgrade
reboot
exit
find /root -name "db.sql"
mysql -u root < "/root/Material_Adicional_TPVMCA/db.sql"
mysql -u root -e "SHOW DATABASES;"
cat/etc/network/interfaces
ip a
ip route
cat /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
ip a 
ip route
nano /etc/network/interfaces
shutdown now
